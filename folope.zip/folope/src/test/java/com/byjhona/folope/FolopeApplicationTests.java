package com.byjhona.folope;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FolopeApplicationTests {

	@Test
	void contextLoads() {
	}

}
